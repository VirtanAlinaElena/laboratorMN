fid = fopen("ex3.txt", "r");
[A, contor] = fscanf(fid, "%d ", [3,3])

diagp = sum(diag(A));
diags = sum(diag(flipud(A)));
col = sum(A);
lin = sum(A');
ok = 1
for i = 1:3
  for j = 1:3
    if (lin(i) != col(j) || lin(i) != diagp || lin(i) != diags || 
        col(j) != diagp || col(j) != diags)
      ok = 0;
    endif 
endfor
endfor

if ok == 0
  disp("NU");
else disp("DA");
endif
fclose(fid);