function ex2b()
  var = input('Variabila este:');
  suma = 0;
  x = 1;
  while x < var
    suma = suma + x;
    x = x + 2;
  endwhile
  disp(suma);
endfunction