function ex2()
  var = input('Introduceti variabila:');
  v = [1 : 2 : var];
  suma = 0;
  for x = v
   suma = suma + x;
  endfor
  disp(suma);
endfunction