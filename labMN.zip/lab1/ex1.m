fid = 0;
while fid < 1
    numefis = input('Deschide fisier: ', 's');
    fid = fopen(numefis, 'w');
    if fid == -1
      disp('Fisierul nu a putut fi deschis');
    endif
endwhile

v = [0 : 0.1 : 1];
for x = v
  fprintf(fid, '%.2f ', 2*x+1);
endfor
fclose(fid);