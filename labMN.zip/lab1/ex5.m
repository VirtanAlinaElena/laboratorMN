function y = NumarAparitii(numefis, sir)
  fid = fopen("ex5.txt", "r");
  linie = fgetl(fid);
  ap = 0;
  while linie != -1
    v = strfind(linie, "cuvinte");
    disp(length(v));
    ap = ap + length(v);
    disp(linie);
    disp("\n");
    linie = fgetl(fid);
  endwhile
  fclose(fid);
  printf("Numarul total de aparitii: ");
  disp(ap);
endfunction

NumarAparitii("ex5.txt", "cuvinte");