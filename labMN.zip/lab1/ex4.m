fid = fopen("ex4.txt", "r");
fseek(fid, 0, 'eof');
x = ftell(fid);
disp(x);
fclose(fid);