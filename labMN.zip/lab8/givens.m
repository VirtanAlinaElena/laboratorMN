function [Q R] = givens(A)
    n = length(A);
    Q = eye(n);
    for i = 1 : n-1
      l = i + 1;
      k = i;
      ro = sqrt(A(l, k) * A(l, k) + A(k, k) * A(k, k));
      cos = A(k, k) / ro;
      sin = -A(l, k) / ro;
      G = eye(n);
      G(k, k) = cos;
      G(k, l) = -sin;
      G(l, k) = sin;
      G(l, l) = cos;
      
      A = G * A;
      Q = Q * G';
    endfor
    R = A;
endfunction