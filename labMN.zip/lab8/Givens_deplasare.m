function [Ys] = Givens_deplasare(A, tol)
  depl = 0;
  n = length(A);
  nrlambdas = 0;
  while n > 2
    lambda = eig(A(n-1 : n, n-1 : n));
    if abs(lambda(1) - A(n, n)) < abs(lambda(2) - A(n, n))
      sigma = lambda(1);
    else
      sigma = lambda(2);
    endif
    depl += sigma;
    B = A - sigma * eye(n);
    
    [Q R]= givens(B);
    A = R * Q;
    if A(n, n-1) < tol
      nrlambdas = nrlambdas + 1;
      Ys(nrlambdas) = A(n, n) + depl;
      A = A(1 : n-1, 1 : n-1);
      n = size(A);
    endif
  endwhile
    
    lambda = eig(A);
    nrlambdas = nrlambdas + 1;
    Ys(nrlambdas) = lambda(1) + depl;
    
    nrlambdas = nrlambdas + 1;
    Ys(nrlambdas) = lambda(2) + depl;
    
endfunction