function [x] = solJacobi(A, b, x0, tol, maxiter)
  n = length(A);
  for p = 1 : maxiter
    for i = 2 : n-1
      sum = A(i, i-1) * x0(i-1) + A(i, i+1) * x0(i+1);
      x(i) = (b(i) - sum) / A(i, i);
    endfor
    x(1) = ( b(1) - A(1,2) * x(2) ) / A(1, 1);
    x(n) = (b(n) - A(n, n-1)*x(n-1)) / A(n, n);
    if norm(x-x0) < tol
      break;
    endif
    x0 = x;
  endfor
endfunction