function x = sort(A, b, x0, w, tol, maxiter)
  n = length(A);
  for p = 1 : maxiter
    for i = 1 : n
      sum = A(i, 1:(i-1)) * x(1:(i-1)) + A(i, (i+1):n) * x0((i+1):n);
      x(i) = w * ((b(i) - sum)) / A(i, i) + (1-w) * x0(i);
    endfor
    if norm(x-x0) < tol
      break;
    endif
    x0 = x;
  endfor
endfunction