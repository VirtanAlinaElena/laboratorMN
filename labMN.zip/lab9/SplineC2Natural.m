function yi = SplineC2Natural(x, y, xi)
  n = length(x); % hi = x(i+1) - x(i)
  A = zeros(n);
  A(1, 1) = 1;
  A(n, n) = 1;
  
  h = [];
  for i = 1 : length(x) - 1
     h(i) = x(i+1) - x(i);
  endfor
  
  for i = 2 : n - 1
    A(i, i-1) = h(i-1);
    A(i, i) = 2 * (h(i-1) + h(i));
    A(i, i+1) = h(i);
  endfor
  
  B = [];
  B(1) = 0;
  B(n) = 0;
  for i = 2 : n - 1
    B(i) = 3 * (y(i+1) - y(i)) / h(i) - 3 * (y(i) - y(i-1)) / h(i-1); 
  endfor
  B = B';
  
  C = inv(A) * B;
  
  for i = 1 : length(x) - 1
    ai = y(i);
    di =  (C(i+1) - C(i))/ (3 * h(i));
    bi = (y(i+1) - y(i)) / h(i) + h(i) * (2 * C(i) - C(i+1)) / 3; 
    if x(i) <= xi && x(i+1) >= xi
      yi = ai + bi * (x(i) - xi) + C(i) * (x(i) - xi)^2 + di * (x(i) - xi)^3;
    endif
  endfor
endfunction