function yi = SplineC1(x, y, dy, xi)
  for i = 1 : length(x) - 1  
    if x(i) <= xi && x(i+1) >= xi
      hi = x(i + 1) - x(i);
      ai = y(i);
      di = y(i+1);
      bi = y(i) + hi/3 * dy(i);
      ci = y(i+1) - hi/3 * dy(i+1);
      t = (xi - x(i)) / hi;
      yi = ai * (1-t)^3 + 3 * bi * t * (1-t)^2 + 3 * ci * t^2 * (1-t) + di * t^3;
    endif
  endfor
endfunction