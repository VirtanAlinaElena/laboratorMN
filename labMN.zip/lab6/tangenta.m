function [x0] = tangenta(x0, tol, p, pderiv)
  dx = - polyval(p, x0) / polyval(pderiv, x0);
  while abs(dx) > tol
    x0 = x0 + dx;
    dx = - polyval(p, x0) / polyval(pderiv, x0);
  endwhile
  
endfunction