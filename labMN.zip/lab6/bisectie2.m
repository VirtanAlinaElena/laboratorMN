function [x0] = bisectie2(a, b, tol, p)
  x0 = (a+b)/2;
  while abs(polyval(p,x0))  >  tol
    if polyval(p, a) * polyval(p, x0) < 0
      b = x0;
    endif
    
    if polyval(p, a) * polyval(p, x0) > 0
      a = x0;
    endif
    
    if polyval(p, a) * polyval(p, x0) == 0
      a = x0;
      b = x0;
    endif
    
    x0 = (a + b) / 2;
  endwhile
endfunction