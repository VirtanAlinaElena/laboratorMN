function [xnew] = bisectie(a, b, tol, p)
  xnew = (a + b) / 2;
  xold = 0;
  while abs((xnew - xold) / xnew)  > tol
    xold = xnew;
    m = (a + b) / 2;
    
    if polyval(p, m) * polyval(p, b) < 0
      a = m;
    endif
    
    if polyval(p, m) * polyval(p, b) > 0
      b = m;
    endif
    
    if polyval(p, m) * polyval(p, b) == 0
      a = m;
      b = m;
    endif
    
    xnew = (a + b) / 2;
  endwhile
endfunction