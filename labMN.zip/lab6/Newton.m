function [n] = Newton(x0, F, J, tol)
  n = 0;
endfunction