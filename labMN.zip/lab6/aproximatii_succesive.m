function [x] = aproximatii_succesive(x0, tol, f)
  y = zeros(1, length(f) - 2);
  y(length(y) + 1) = 1;
  y(length(y) + 1) = 0;
  g = y + f;
  x = polyval(g, x0);
  while abs(polyval(f, x)) >= tol
    x = polyval(g, x);
   endwhile 
endfunction