function [x] = secanta(a, b, tol, p)
  x = (a * polyval(p, b) - b * polyval(p, a)) / (polyval(p, b) - polyval(p, a));
  
  while abs(polyval(p, x)) > tol
    if polyval(p, x) * polyval(p, b) < 0
      a = x;
    endif
    
    if polyval(p, x) * polyval(p, b) > 0
      b = x;
    endif
    
    if polyval(p, x) * polyval(p, b) == 0
      a = x;
      b = x;
    endif
    
  x = (a * polyval(p, b) - b * polyval(p, a)) / (polyval(p, b) - polyval(p, a));
  
  endwhile
endfunction