function [A, b] = GPPS(A, b)
  [n n] = size(A);
  S = zeros(n, 1);
  
  for p = 1 : n-1
    pivot = -inf;
    linie_pivot = -1;
    
    for i = 1 : n
      S(i) = sum(A(i, 1:n));
    endfor
    
    max = 0;
    for i = p : n
      pivot = A(i, p) / S(i);
      if pivot > max
        max = pivot;
        linie_pivot = i;
      endif
    endfor
    pivot = max;
      
    if p != linie_pivot
     for j = p : n
      t = A(p, j);
      A(p, j) = A(linie_pivot, j);
      A(linie_pivot, j) = t;
     endfor
   endif
  
    t = b(linie_pivot);
    b(linie_pivot) = b(p);
    b(p) = t;
  
    for i = p + 1 : n
       if A(p, p) == 0
          continue;
       endif
      
      tp = A(i, p)/A(p, p);
      A(i, p) = 0;
      
      for j = p + 1 : n
        A(i, j) = A(i, j) - tp * A(p, j);
      endfor
      
      b(i) = b(i) - tp * b(p);
    endfor
  endfor
endfunction