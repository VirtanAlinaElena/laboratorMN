function rez = functie(x, y)
  rez = y * sin(x) - 1;
endfunction