# Created by Octave 4.2.2, Thu Mar 21 23:29:49 2019 EET <alinavirtan@alinavirtan-Lenovo-YOGA-510-15IKB>
# name: A
# type: matrix
# rows: 2
# columns: 2
 2 2
 1 3


# name: D
# type: diagonal matrix
# rows: 3
# columns: 3
1
10
8


# name: L
# type: matrix
# rows: 3
# columns: 3
 1 0 0
 6 10 0
 -1 7 8


# name: U
# type: matrix
# rows: 3
# columns: 3
 1 5 -3
 0 10 2
 0 0 8


# name: ans
# type: diagonal matrix
# rows: 3
# columns: 3
1
10
8


# name: v
# type: matrix
# rows: 3
# columns: 1
 1
 10
 8


