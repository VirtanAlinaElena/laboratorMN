function [Q R] = Householder(A)
  [n n] = size(A);
  Q = eye(n);
  for p = 1 : (n-1)
    v = zeros(n, 1);
    
    v(p+1 : n) = A(p+1 : n, p);
    
    v(p) = A(p, p) + sign(A(p, p)) * norm(A(p : n, p)); 
   
    H = eye(n) - 2 * v * v'/(v' * v);
    A = H * A;
    Q = Q * H'; 
  endfor
  R = A;
endfunction