function ex1()
  fid = fopen('valori.txt', 'w');
  v = [0: 0.1: 1]; 
  for x=v
    fprintf(fid, '%f ', 2*x+1);
  endfor
  fclose(fid);
endfunction