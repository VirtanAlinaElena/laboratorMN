function [success] = ConvergesJacobi(A)
    % Completați următoarele linii pentru a stabili daca matricea A converge pentru metoda Jacobi
    D = diag(diag(A));
    L = tril(A) - diag(diag(A));
    U = triu(A) - diag(diag(A));
    N = D;
    P = L + U;
    G = inv(D) * (L + U)
    % Calculați raza spectrală a matricei G
    spectral_radius = max(abs(eig(G)));
    if spectral_radius < 1
        success = 1;
    else
        succes = 0;
    endif
endfunction