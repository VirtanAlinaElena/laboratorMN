function [x1 l1 k] = MPI(A, N, u, eps)
  [n n] = size(A);
  y0 = ones(n, 1);
  
  for i = 1 : N
    y = inv(A - u * eye(n)) * y0;
    y = y / norm(y, inf);
    if norm(y-y0, inf) / norm(y0, inf) < eps
      break;
    endif
    y0 = y;
  endfor
  l1 = (y' * A * y) / (y' * y); % cea mai mare val proprie in modul
  x1 = y; % vectorul propriu catre care converge
  k = i; % dupa k pasi converge metoda
endfunction 
