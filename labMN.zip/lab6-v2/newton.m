function [x, n] = newton(x0, F, J, tol)
  n = 0;
  x = x0 - inv(J(x0(1), x0(2))) * F(x0(1), x0(2));
  n = n + 1;
  while (abs(x - x0) > tol)
    x0 = x;
    x = x0 - inv(J(x0(1), x0(2))) * F(x0(1), x0(2));
    n = n + 1;
  endwhile
endfunction