function x0 = tangenta(x0, tol, f, fderiv)
  dx = f(x0) / fderiv(x0);
  while abs(dx) > tol
    x0 = x0 - dx;
    dx = f(x0) / fderiv(x0);
  endwhile
endfunction