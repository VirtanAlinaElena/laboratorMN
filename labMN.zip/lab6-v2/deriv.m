function fderiv = deriv(x)
  fderiv = 3 * x^2 - 4 * x + 5;
endfunction