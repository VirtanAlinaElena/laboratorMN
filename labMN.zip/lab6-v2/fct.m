function F = fct(x, y)
  f1 = x^2 + y^2 - 5 * x ;
  f2 = sin(y) + cos(x) - 1;
  F = [f1; f2];
endfunction