function var = secanta(a, b, f, tol)
  m = 0;
  while ((abs)(b - a) / (2^m) > tol)
    sol = a - f(a) * (a - b) / (f(a) - f(b));
    if (f(a) * f(sol) < 0)
      b = sol;
    elseif (f(sol) * f(b) < 0)
      a = sol;
    endif
    m = m + 1;
  endwhile
endfunction