function f = ecuatie(x)
  f = x^3 - 2 * x^2 + 5 * x - 7;
endfunction