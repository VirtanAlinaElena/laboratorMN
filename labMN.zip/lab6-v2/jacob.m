function J = jacob(x, y)
  J = [2*x-5 2*y; -sin(x) cos(y)];
endfunction