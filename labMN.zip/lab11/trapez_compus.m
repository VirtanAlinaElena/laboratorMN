function integrala = trapez_compus(a, b, N)
  h = (b - a) / N;
  fa = exp(3 * a);
  fb = exp(3 * b);
  
  sum = 0;
  for i = 1 : N - 1
    sum = sum + exp(3 * (a + i * h));
  endfor
  integrala = h * (fa + fb + 2 * sum) / 2;
endfunction