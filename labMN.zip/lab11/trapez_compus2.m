function integrala = trapez_compus2(a, b, N)
  h = (b - a) / N;
  fa = log(1 + a * a);
  fb = log(1 + b * b);
  
  sum = 0;
  for i = 1 : N - 1
    sum = sum + log(1 + (a + i * h) * (a + i * h));
  endfor
  integrala = h * (fa + fb + 2 * sum) / 2;
endfunction