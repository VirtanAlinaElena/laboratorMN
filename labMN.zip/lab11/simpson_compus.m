function integrala = simpson_compus(a, b, N)
  h = (b - a) / N;
  fa = a * log(a);
  fb = b * log(b);
  
  sum1 = 0;
  for i = 1 : N/2
    x = a + (2 * i - 1) * h;
    sum1 = sum1 + x * log(x);
  endfor
  
  sum2 = 0;
  for i = 1 : N/2 - 1
    x = a + 2 * i * h;
    sum2 = sum2 + x * log(x);
  endfor
  
  integrala = h * (fa + fb + 4 * sum1 + 2 * sum2) / 3;
  
endfunction