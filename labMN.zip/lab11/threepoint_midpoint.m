function fderiv = threepoint_midpoint(x1, x0)
    h = x1 - x0;
    fderiv = (exp(3 * (x0 + h)) - exp(3 * (x0 - h))) / (2 * h);
  endfor
endfunction